package app;

public abstract class Vehicle {
    protected String name;

    public Vehicle(String name){
        this.name = name;
    }

    public void move(){
        System.out.println("Vehicle " + name + " is moving");
    }

    public abstract String getYearOfInvention();
}
