package app;

public class Tank extends Vehicle{

    public Tank(String name) {
        super(name);
    }

    @Override
    public String getYearOfInvention() {
        return "1915";
    }
}
