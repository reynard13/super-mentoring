package app;

public class Boat extends Vehicle{

    public Boat(String name) {
        super(name);
    }

    @Override
    public String getYearOfInvention(){
        return "8200 BC";
    }
}
