package app;

import java.util.ArrayList;
import java.util.Arrays;

public class Runner {

    public static void main(String[] args) {
        ArrayList<Vehicle> vehicles = new ArrayList<>(Arrays.asList(new Tank("T34"),
                new Car("BMW"), new Bicycle("Azimut"), new MotorCycle("Kawasaki"),
                new Boat("Lund")));

        for(Vehicle v : vehicles){
            v.move();
            System.out.println(v.getYearOfInvention());
        }
    }
}
