package app;

public class MotorCycle extends Vehicle{

    public MotorCycle(String name) {
        super(name);
    }

    @Override
    public String getYearOfInvention() {
        return "1885";
    }
}
