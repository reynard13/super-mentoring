package app;

public class Car extends Vehicle{

    public Car(String name) {
        super(name);
    }

    @Override
    public String getYearOfInvention(){
        return "1885";
    }
}
